<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
export default  {
  name:  'App'
}
</script>

<style>
.btn-prev,.btn-next{
  border: none;
  height: 28px!important;
}
</style>
