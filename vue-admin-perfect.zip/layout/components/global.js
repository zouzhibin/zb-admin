import Vue from 'vue'
const global = new Vue()
export default global
