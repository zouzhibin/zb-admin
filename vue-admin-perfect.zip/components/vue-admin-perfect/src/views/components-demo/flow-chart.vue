<template>
  <div>
    <zb-pipeline/>
  </div>
</template>

<script lang="ts" setup>
import ZbPipeline from "@/components/pipeline/index.vue";
</script>

<style>

</style>
