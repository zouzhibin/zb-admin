export const chatData = [
    {
        is_self:0,
        created_at:'2022-03-11',
        content:'hello 你好呀!',
        id:1
    },
    {
        is_self:1,
        created_at:'2022-03-11',
        content:'hello 你好呀!',
        id:2,
        type:1, // 文字
    }
]
