<template>
  <div>
    <div style="margin-bottom: 15px">聊天内容框，功能有发送emoji表情，上传图片，发送图片，内容滚动，发送文字</div>
    <u-chat-box/>
  </div>

</template>

<script lang="ts" setup>
  import UChatBox from './components/u-chartBox/index.vue'
</script>

<style>

</style>
