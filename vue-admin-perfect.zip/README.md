vue-element-perfect 是一个后台前端解决方案, 基于Vue3.0+TS+Element-plus实现。它使用了最新的前端技术栈、动态路由，权限验证，并且有着丰富的组件。


## 效果预览

#### 在线预览点击 —— [企业级、通用型中后台前端解决方案 ](http://182.61.5.190:8889/)

附上github地址点击跳转 [vue-admin-perfect](https://github.com/zouzhibin/vue-admin-perfect)

## 项目 uniapp 分支

```
# 克隆项目 切换 uniapp分支
git clone https://github.com/zouzhibin/vue-admin-perfect.git

# 安装依赖
yarn

# 本地开发 启动项目
hbuilder运行浏览器启动
```
## 项目 master 分支

```
# 克隆项目
git clone https://github.com/zouzhibin/vue-admin-perfect.git

# 安装依赖
yarn

# 本地开发 启动项目
yarn serve
```




