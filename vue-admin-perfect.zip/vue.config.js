module.exports = {
    publicPath: "./"
};
